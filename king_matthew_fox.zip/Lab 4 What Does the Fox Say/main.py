'''
Matthew King
05/20/2014
DPW 1405
Lab 4 What Does the Fox Say
'''

import webapp2

class MainHandler(webapp2.RequestHandler):
    def get(self):
    	p = Page()

    	k = Kinkajou()
    	k.sounds = ['kit kit kit kow', 'buzz buzz buzz bozz', 'webt webt webt wob']

    	e = Eel()
    	e.sounds = ['kit kit kit kow', 'buzz buzz buzz bozz', 'webt webt webt wob']

    	f = Frog()
    	f.sounds = ['kit kit kit kow', 'buzz buzz buzz bozz', 'webt webt webt wob']

        if self.request.GET:
        	name = self.request.GET['name']
        	title = name + "'s Information"
	        phylum = self.request.GET['phylum']
	    	clss = self.request.GET['clss']
	    	order = self.request.GET['order']
	    	family = self.request.GET['family']
	    	genus = self.request.GET['genus']
	    	url = self.request.GET['url']
	    	avg = self.request.GET['avg']
	    	habitat = self.request.GET['habitat']
	    	geoloc = self.request.GET['geoloc']
	    	sound = self.request.GET['sound']
        	p.page_head = p.page_head.format(**locals())
	        p.display_info = p.display_info.format(**locals())
	        self.response.write(p.page_head + p.display_info + p.page_close)
        else:
        	title = 'What Does the Amazon Say?'
        	p.page_head = p.page_head.format(**locals())
        	p.page_nav = p.page_nav.format(**locals())
        	self.response.write(p.page_head + p.page_nav + p.page_close)

class Page(object):
	def __init__(self):
		self.page_head = '''<!DOCTYPE HTML>
<html>
	<head>
		<title>{title}</title>
		<link href="css/style.css" rel="stylesheet" type="text/css" />
	</head>
	<body>'''
		self.page_nav = '''<ul>
			<li><a href="?name={k.name}&phylum={k.phylum}&clss={k.clss}&order={k.order}&family={k.family}&genus={k.genus}&url={k.url}&avg={k.avg}&habitat={k.habitat}&geoloc={k.geoloc}&sound={k.sound}">Kinkajou</a></li>
			<li><a href="?name={e.name}&phylum={e.phylum}&clss={e.clss}&order={e.order}&family={e.family}&genus={e.genus}&url={e.url}&avg={e.avg}&habitat={e.habitat}&geoloc={e.geoloc}&sound={e.sound}">Eel</a></li>
			<li><a href="?name={f.name}&phylum={f.phylum}&clss={f.clss}&order={f.order}&family={f.family}&genus={f.genus}&url={f.url}&avg={f.avg}&habitat={f.habitat}&geoloc={f.geoloc}&sound={f.sound}">Frog</a></li>
		</ul>'''
		self.display_info = '''<table id='wrapper'>
			<tr>
				<td>		
					<table>
						<tr>
							<th>Phylum:</th>
							<th>Class:<th>
						</tr>
						<tr>
							<td>{phylum}</td>
							<td>{clss}<td>
						</tr>
						<tr>
							<th>Order:</th>
							<th>Family:<th>
						</tr>
						<tr>
							<td>{order}</td>
							<td>{family}<td>
						</tr>
						<tr>
							<th>Genus:</th>
							<th>Average Lifespan:<th>
						</tr>
						<tr>
							<td>{genus}</td>
							<td>{avg}<td>
						</tr>
						<tr>
							<th>Habitat:</th>
							<th>Geolocation:<th>
						</tr>
						<tr>
							<td>{habitat}</td>
							<td>{geoloc}<td>
						</tr>
						<tr>
							<th>Sound:</th>
							<th><th>
						</tr>
						<tr>
							<td>{sound}</td>
							<td><td>
						</tr>
					</table>
				</td>
				<td>
					<img src={url} width="300" />
				</td>
			</tr>
		</table>
		<a href='?'>Go Back</a>'''
		self.page_close = '''</body>
</html>'''

class Animal(object):
	def __init__(self):
		self.name = ''
		self.phylum = ''
		self.clss = ''
		self.order = ''
		self.family = ''
		self.genus = ''
		self.url = ''
		self.avg = ''
		self.habitat = ''
		self.geoloc = ''

class Kinkajou(Animal):
	def __init__(self):
		super(Animal, self).__init__()
		self.name = 'Kinkajou'
		self.phylum = 'Chordata'
		self.clss = 'Mammalia'
		self.order = 'Carnivora'
		self.family = 'Procyonidae'
		self.genus = 'Potos'
		self.url = 'images/kinkajou.jpg'
		self.avg = '23 years'
		self.habitat = 'Forest'
		self.geoloc = 'Amazon'
		self.__sounds = []
		self.sound =''

	@property
	def sounds(self):
		pass

	@sounds.setter
	def sounds(self, arr):
		self.__sounds = arr
		self.sound += arr[0]

class Eel(Animal):
	def __init__(self):
		super(Animal, self).__init__()
		self.name = 'Electric Eel'
		self.phylum = 'Chordata'
		self.clss = 'Actinopterygii'
		self.order = 'gymnotiformes'
		self.family = 'gymnotidae'
		self.genus = 'electrophorus'
		self.url = 'images/eel.jpg'
		self.avg = '15 years'
		self.habitat = 'River'
		self.geoloc = 'Amazon'
		self.__sounds = []
		self.sound =''

	@property
	def sounds(self):
		pass

	@sounds.setter
	def sounds(self, arr):
		self.__sounds = arr
		self.sound += arr[1]

class Frog(Animal):
	def __init__(self):
		super(Animal, self).__init__()
		self.name = 'Poison Dart Frog'
		self.phylum = 'Chordata'
		self.clss = 'Amphibia'
		self.order = 'Anura'
		self.family = 'Dendrobatidae'
		self.genus = 'Dendrobates'
		self.url = 'images/frog.jpg'
		self.avg = '3 to 15 years'
		self.habitat = 'Tropical Forests'
		self.geoloc = 'Amazon'
		self.__sounds = []
		self.sound =''

	@property
	def sounds(self):
		pass

	@sounds.setter
	def sounds(self, arr):
		self.__sounds = arr
		self.sound += arr[2]

app = webapp2.WSGIApplication([
    ('/', MainHandler)
], debug=True)
